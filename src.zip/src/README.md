Create and activate virtual environment
`python -m venv .venv`  
Activate virtualenv on windows:
`.venv/Scripts/activate`
Activate virtualenv on mac:  
`source .venv/bin/activate`  

Install all packages
`pip install -r requirements.txt`
